package pt.ulusofona.aed.rockindeisi2023;

public class ExecFunctions
{

    //TODO Retorna o total de temas musicais que foram lançados no ano X. Input: "COUNT_SONGS_YEAR 2000"
    public static void count_Songs_Year(String[] args)
    {

    }
    //TODO Opcional Necessária. Input: "COUNT_DUPLICATE_SONGS_YEAR 2000"
    public static void count_Duplicate_Songs_Year(String[] args)
    {

    }

    //TODO Função Obrigatoria. Input : "GET_SONGS_BY_ARTIST 10 Nine Inch Nails"
    public static void get_Songs_By_Artists(String[] args)
    {

    }


    //TODO Função Obrigatoria. Input : "GET_MOST_DANCEABLE 2011 2013 3"
    public static void get_Most_Danceable(String[] args)
    {

    }

    public static void get_Artists_One_Song(String[] args)
    {

    }

    public static void get_Top_Artists_With_Songs_Between(String[] args)
    {

    }

    public static void most_Frequent_Words_In_Artist_Name(String[] args)
    {

    }

    public static void get_Unique_Tags(String[] args)
    {

    }

    public static void get_Unique_Tags_In_Between_Years(String[] args)
    {

    }

    public static void get_Rising_Stars(String[] args)
    {

    }

    //TODO Função Obrigatoria. Input: "ADD_TAGS Nirvana;Rockalhada"
    public static void add_Tags(String[] args)
    {

    }

    //TODO Função Obrigatoria. REMOVE_TAGS Nirvana;Rockalhada
    public static void remove_Tags(String[] args)
    {

    }

    //TODO Função Obrigatoria. Input: "GET_ARTISTS_FOR_TAG Rockalhada"
    public static void get_Artists_For_Tag(String[] args)
    {

    }
}
