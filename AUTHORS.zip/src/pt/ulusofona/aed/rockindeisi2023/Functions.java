package pt.ulusofona.aed.rockindeisi2023;

public class Functions
{

    //TODO Retorna o total de temas musicais que foram lançados no ano X.
    public static void count_Songs_Year()
    {

    }

    public static void count_Duplicate_Songs_Year()
    {

    }

    //TODO Função Obrigatoria
    public static void get_Songs_By_Artists(int numResultados, String nome)
    {

    }


    //TODO Função Obrigatoria
    public static void get_Most_Danceable()
    {

    }

    public static void get_Artists_One_Song()
    {

    }

    public static void get_Top_Artists_With_Songs_Between()
    {

    }

    public static void most_Frequent_Words_In_Artist_Name()
    {

    }

    public static void get_Unique_Tags()
    {

    }

    public static void get_Unique_Tags_In_Between_Years()
    {

    }

    public static void get_Rising_Stars()
    {

    }

    //TODO Função Obrigatoria
    public static void add_Tags()
    {

    }

    //TODO Função Obrigatoria
    public static void remove_Tags()
    {

    }

    //TODO Função Obrigatoria
    public static void get_Artists_Por_Tag()
    {

    }
}
