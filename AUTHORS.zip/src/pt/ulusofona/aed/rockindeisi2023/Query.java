
package pt.ulusofona.aed.rockindeisi2023;

import java.util.ArrayList;

public class Query
{
    String name;
    String[] args;

    public Query() {

    }

    public Query(String name, String[] args) {
        this.name = name;
        this.args = args;
    }
}
