package pt.ulusofona.aed.rockindeisi2023;

public enum Querys
{
    COUNT_SONGS_YEAR,
    GET_SONGS_BY_ARTIST,
    GET_MOST_DANCEABLE,
    ADD_TAGS,
    REMOVE_TAGS,
    GET_ARTISTS_FOR_TAG,
    EXIT
}
